function forkprint(fid,str);

fprintf(fid,'%s',str);
fprintf(str);
end