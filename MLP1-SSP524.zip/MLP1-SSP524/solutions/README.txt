Directory to store the computed solutions.
