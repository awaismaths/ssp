Directory to store the computed norms of the various quantities.
