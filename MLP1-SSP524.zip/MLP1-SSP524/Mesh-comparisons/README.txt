Directory to store .mat files created when interpolating between meshes.
